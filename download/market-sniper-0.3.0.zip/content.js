// content.js — парсер карточки Яндекс.Маркета, расчёт чистой прибыли и бейдж на странице.
// Изолированный мир расширения: DOM общий, переменные страницы не видны (и наоборот).
(function () {
  'use strict';

  // Карта селекторов. data-auto / data-zone-name стабильнее классов ds-text_*.
  var SELECTORS = {
    priceZone: '[data-zone-name="price"]',
    priceCurrent: '[data-auto="snippet-price-current"]',
    priceOld: '[data-auto="snippet-price-old"]',
    title: '[data-auto="productCardTitle"]',
    shopBlock: '[data-auto="shop-info-block"]',
    shopTitle: '[data-auto="shop-info-title"]',
    shopLink: '[data-auto="shop-info-link"]',
    offersZone: '[data-zone-name="morePrices"]',
    offersLink: '[data-auto="offersEntrypoint"]'
  };

  var BADGE_ID = 'ms-profit-badge';
  var STORAGE_KEY = 'ms-settings';
  var DEFAULTS = (typeof MS_DEFAULTS !== 'undefined') ? MS_DEFAULTS : {
    commission: 0.10, logistics: 100, ads: 0, model: 'FBS', category: 'Все товары'
  };

  var settings = Object.assign({}, DEFAULTS);
  var access = { mode: 'trial', daysLeft: 0, expiresAt: null, purchaseUrl: '' };
  var lastSignature = '';
  var refreshTimer = null;

  // В урезанном режиме (пробный период закончился) считаем только по базовым ставкам.
  function currentSettings() {
    if (access.mode === 'expired') return Object.assign({}, DEFAULTS);
    return settings;
  }

  // ---------- Парсинг ----------

  // "2 892 ₽" / "104 677" / "1 234,50 ₽" -> число
  function parsePrice(text) {
    if (!text) return null;
    var cleaned = String(text).replace(/[^\d.,]/g, '').replace(',', '.');
    var value = parseFloat(cleaned);
    return isFinite(value) && value > 0 ? value : null;
  }

  function normText(text) {
    return text ? String(text).replace(/\s+/g, ' ').trim() : '';
  }

  function isProductPage() {
    // Карточка Маркета живёт на двух путях: /product--<slug>/<id> и /card/<slug>/<id> (canonical).
    var p = location.pathname;
    return p.indexOf('/product') === 0 || p.indexOf('/card/') === 0;
  }

  function getPriceEl() {
    // data-zone-name="price" есть и в сниппетах поиска — парсим только карточку товара.
    if (!isProductPage()) return null;
    var zone = document.querySelector(SELECTORS.priceZone);
    var el = zone ? zone.querySelector(SELECTORS.priceCurrent) : null;
    if (!el) el = document.querySelector(SELECTORS.priceCurrent);
    return el;
  }

  function getPrice() {
    var el = getPriceEl();
    return el ? parsePrice(el.textContent) : null;
  }

  function getOldPrice() {
    if (!isProductPage()) return null;
    var zone = document.querySelector(SELECTORS.priceZone);
    if (!zone) return null;
    var el = zone.querySelector(SELECTORS.priceOld);
    return el ? parsePrice(el.textContent) : null;
  }

  function getSeller() {
    if (!isProductPage()) return { name: null, url: null };
    var block = document.querySelector(SELECTORS.shopBlock);
    if (!block) return { name: null, url: null };
    var titleEl = block.querySelector(SELECTORS.shopTitle);
    var linkEl = block.querySelector(SELECTORS.shopLink);
    return {
      name: titleEl ? normText(titleEl.textContent) : null,
      url: linkEl && linkEl.href ? linkEl.href : null
    };
  }

  // Блок "Ещё предложения": data-zone-data = {"numOffers":74,"url":"/offers/..."}
  function getOffers() {
    var zone = document.querySelector(SELECTORS.offersZone);
    if (zone) {
      try {
        var raw = zone.getAttribute('data-zone-data');
        if (raw) {
          var data = JSON.parse(raw);
          return {
            count: typeof data.numOffers === 'number' ? data.numOffers : null,
            url: data.url ? new URL(data.url, location.origin).href : null
          };
        }
      } catch (e) { /* битый JSON — не критично */ }
    }
    var link = document.querySelector(SELECTORS.offersLink);
    return { count: null, url: link && link.href ? link.href : null };
  }

  // ---------- Расчёт ----------

  // profit = price * (1 - commission) - logistics - ads
  function calcProfit(price, cfg) {
    var c = cfg || currentSettings();
    var commission = Number(c.commission) || 0;
    var logistics = Number(c.logistics) || 0;
    var ads = Number(c.ads) || 0;
    return Math.round(price * (1 - commission) - logistics - ads);
  }

  function calcMargin(price, profit) {
    if (!price) return null;
    return Math.round((profit / price) * 1000) / 10; // % с одним знаком
  }

  function fmt(value) {
    if (value === null || value === undefined || !isFinite(value)) return '—';
    return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 }).format(Math.round(value));
  }

  function pct(value) {
    var n = Math.round((Number(value) || 0) * 1000) / 10;
    return String(n).replace('.', ',') + '%';
  }

  // Русские склонения: 1 предложение, 2 предложения, 5 предложений.
  function plural(count, one, few, many) {
    var n = Math.abs(Math.round(Number(count) || 0));
    var mod10 = n % 10;
    var mod100 = n % 100;
    if (mod10 === 1 && mod100 !== 11) return one;
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
    return many;
  }

  function collect() {
    var price = getPrice();
    var oldPrice = getOldPrice();
    var seller = getSeller();
    var offers = getOffers();
    var titleEl = document.querySelector(SELECTORS.title);
    var profit = price ? calcProfit(price) : null;
    var active = currentSettings();

    return {
      status: price ? 'ok' : 'no-price',
      url: location.href,
      title: titleEl ? normText(titleEl.textContent) : document.title,
      price: price,
      oldPrice: oldPrice,
      discount: (price && oldPrice && oldPrice > price)
        ? Math.round((1 - price / oldPrice) * 100) : null,
      seller: seller.name,
      sellerUrl: seller.url,
      offersCount: offers.count,
      offersUrl: offers.url,
      profit: profit,
      margin: price ? calcMargin(price, profit) : null,
      access: {
        mode: access.mode,
        daysLeft: access.daysLeft,
        expiresAt: access.expiresAt,
        keyError: access.keyError || null
      },
      settings: {
        commission: active.commission,
        logistics: active.logistics,
        ads: active.ads,
        model: active.model,
        category: active.category
      }
    };
  }

  // ---------- UI ----------

  function removeBadge() {
    var badge = document.getElementById(BADGE_ID);
    if (badge) badge.remove();
  }

  function ensureBadge() {
    var badge = document.getElementById(BADGE_ID);
    if (badge) return badge;

    var anchor = document.querySelector(SELECTORS.priceZone);
    if (!anchor || !anchor.parentNode) return null;

    badge = document.createElement('div');
    badge.id = BADGE_ID;
    badge.setAttribute('data-ms', 'badge');
    badge.style.cssText = [
      'display:flex', 'flex-direction:column', 'gap:2px',
      'margin:8px 0 6px', 'padding:8px 12px', 'border-radius:12px',
      'background:linear-gradient(135deg,#0b1f3a,#17395f)', 'color:#ffffff',
      'font:600 14px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif',
      'box-shadow:0 2px 10px rgba(11,31,58,.25)', 'max-width:100%'
    ].join(';');

    anchor.parentNode.insertBefore(badge, anchor.nextSibling);
    return badge;
  }

  function renderBadge(data) {
    if (!isProductPage() || !data.price) { removeBadge(); return; }
    var badge = ensureBadge();
    if (!badge) return;

    badge.textContent = '';

    var active = currentSettings();
    var commission = Number(active.commission) || 0;
    var commissionMoney = data.price * commission;
    var modelShort = (typeof msModelShort === 'function') ? msModelShort(active.model) : String(active.model || '');
    var modelFull = (typeof msModelFull === 'function') ? msModelFull(active.model) : '';

    var main = document.createElement('span');
    main.style.cssText = 'font-size:16px;color:' + (data.profit >= 0 ? '#f5c451' : '#ff8a80');
    main.textContent = 'Чистая прибыль ≈ ' + fmt(data.profit) + ' ₽' +
      (data.profit < 0 ? ' (уходите в минус)' : '');
    badge.appendChild(main);

    var sub = document.createElement('span');
    sub.style.cssText = 'font-size:11px;font-weight:400;color:#c9d6e8';
    sub.textContent = 'Маркет ' + fmt(commissionMoney) + ' ₽ (' + pct(commission) + ')' +
      ' · доставка ' + fmt(active.logistics) + ' ₽' +
      ' · реклама ' + fmt(active.ads) + ' ₽';
    badge.appendChild(sub);

    var facts = [];
    if (data.margin !== null) facts.push('Остаётся ' + String(data.margin).replace('.', ',') + '% цены');
    if (modelShort) facts.push('схема: ' + modelShort);

    if (facts.length) {
      var line = document.createElement('span');
      line.style.cssText = 'font-size:11px;font-weight:400;color:#9fb3cc';
      line.textContent = facts.join(' · ');
      badge.appendChild(line);
    }

    var shopFacts = [];
    if (data.seller) shopFacts.push('магазин: ' + data.seller);
    if (data.offersCount) {
      shopFacts.push('ещё ' + data.offersCount + ' ' +
        plural(data.offersCount, 'предложение', 'предложения', 'предложений'));
    }

    if (shopFacts.length) {
      var shopLine = document.createElement('span');
      shopLine.style.cssText = 'font-size:11px;font-weight:400;color:#9fb3cc';
      shopLine.textContent = shopFacts.join(' · ');
      badge.appendChild(shopLine);
    }

    badge.title = 'Как считаем: цена минус комиссия Маркета, минус доставка, минус реклама.' +
      (modelFull ? ' Схема работы: ' + modelFull + '.' : '');

    // Пробный период закончился: базовый расчёт остаётся, но зовём в полную версию.
    if (access.mode === 'expired' && typeof MS_LICENSE !== 'undefined') {
      var promo = document.createElement('a');
      promo.href = MS_LICENSE.PURCHASE_URL;
      promo.target = '_blank';
      promo.rel = 'noopener';
      promo.style.cssText = 'font-size:11px;font-weight:600;color:#f5c451;text-decoration:underline';
      promo.textContent = 'Пробный период закончился — полная версия за ' +
        ((typeof msPriceLabel === 'function') ? msPriceLabel('month') : '199 ₽/мес');
      badge.appendChild(promo);
    }
  }

  function refresh() {
    try {
      renderBadge(collect());
    } catch (e) {
      console.warn('[Маркет-Снайпер] не удалось обновить бейдж:', e && e.message);
    }
  }

  function scheduleRefresh(delay) {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(refresh, delay || 400);
  }

  // ---------- SPA-навигация ----------

  // Лёгкая подпись состояния: меняется — пересчитываем (Маркет подменяет DOM без перезагрузки).
  // Наличие бейджа в подписи важно: при перерисовке страница может снести наш блок,
  // а цена и магазин останутся теми же.
  function signature() {
    var priceEl = getPriceEl();
    var sellerEl = document.querySelector(SELECTORS.shopBlock + ' ' + SELECTORS.shopTitle);
    return location.pathname + '|' + (priceEl ? priceEl.textContent : '') +
      '|' + (sellerEl ? sellerEl.textContent : '') +
      '|' + (document.getElementById(BADGE_ID) ? '1' : '0') +
      '|' + access.mode;
  }

  function startWatching() {
    var observer = new MutationObserver(function () {
      if (signature() !== lastSignature) scheduleRefresh(400);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });

    // Страховка: часть блоков дорисовывается без мутаций в наблюдаемом поддереве.
    setInterval(function () {
      var sig = signature();
      if (sig !== lastSignature) {
        lastSignature = sig;
        refresh();
      }
    }, 1200);
  }

  // ---------- Настройки ----------

  function loadSettings() {
    return new Promise(function (resolve) {
      try {
        if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
          resolve(settings);
          return;
        }
        chrome.storage.local.get(STORAGE_KEY, function (res) {
          var stored = (res && res[STORAGE_KEY]) || {};
          settings = Object.assign({}, DEFAULTS, stored);
          resolve(settings);
        });
      } catch (e) {
        resolve(settings);
      }
    });
  }

  function loadAccess() {
    if (typeof msGetAccess !== 'function') return Promise.resolve(access);
    return msGetAccess().then(function (state) {
      access = state;
      return access;
    }, function () {
      return access;
    });
  }

  // ---------- Обмен с попапом ----------

  chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    if (!msg || !msg.type) return;

    if (msg.type === 'COLLECT') {
      sendResponse(collect());
      return true;
    }

    if (msg.type === 'SETTINGS_UPDATED') {
      loadSettings().then(loadAccess).then(function () {
        lastSignature = '';
        refresh();
        sendResponse(collect());
      });
      return true;
    }
  });

  // ---------- Старт ----------

  loadSettings()
    .then(loadAccess)
    .then(function () {
      lastSignature = signature();
      refresh();
      startWatching();
      console.log('[Маркет-Снайпер] content script готов, режим: ' + access.mode);
    });
})();