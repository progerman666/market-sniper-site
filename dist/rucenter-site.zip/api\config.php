<?php
// Настройки API «Маркет-Снайпер». Файл закрыт .htaccess — не отдаётся в браузер.
// Дополнительная защита на случай сервера без .htaccess:
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    http_response_code(404);
    exit;
}

$adminSecret = getenv('MS_ADMIN_SECRET');

return [
    // Пароль для выдачи ключей. Обязательно замените перед публикацией!
    'admin_secret' => $adminSecret !== false && $adminSecret !== '' ? $adminSecret : 'ЗАМЕНИТЕ_ЭТОТ_ПАРОЛЬ',

    // Приватный ключ подписи (ECDSA P-256). Лежит вне веб-доступа (.htaccess), лучше — вообще вне public_html.
    'private_key_path' => getenv('MS_PRIVATE_KEY_PATH') ?: __DIR__ . '/keys/private.pem',

    // Куда писать журнал выдачи и список отозванных ключей.
    'data_dir' => getenv('MS_DATA_DIR') ?: __DIR__ . '/data',

    // Стартовая цена: поднимаем по мере роста установок и рейтинга.
    'plans' => [
        'month' => ['days' => 30, 'price' => 199],
        'year' => ['days' => 365, 'price' => 1990],
    ],
];
