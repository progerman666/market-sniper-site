# Сайт «Маркет-Снайпер» для обычного хостинга (Ru-Center, PHP)

Этот архив — готовый `public_html`: лендинг, страница оплаты, документы и PHP-API выдачи ключей.
Cloudflare не используется, всё работает на российском хостинге.

## Структура

```
index.html        главная (hero, что показывает, как работает, цена, установка, FAQ)
buy.html          оплата по СБП и получение ключа
privacy.html      политика конфиденциальности (нужна для ревью в Edge)
offer.html        публичная оферта
styles.css        стили
img/              скриншоты расширения и иконка
download/         market-sniper-0.3.0.zip — то, что скачивает покупатель
api/
  plans.php       GET  — цены (их читает и лендинг, и расширение)
  issue.php       POST — выдать ключ (заголовок X-Admin-Secret)
  check.php       GET  — проверка/отзыв ключа: ?key=MS1...
  admin.php       страница выдачи ключа после оплаты (пароль = admin_secret)
  config.php      настройки: пароль, тарифы, путь к ключу (закрыт .htaccess)
  keys/private.pem   приватный ключ подписи (закрыт .htaccess)
  data/           журнал выдачи и revoked.json (закрыт .htaccess)
.htaccess         HTTPS-редирект, запрет листинга
robots.txt
```

## Загрузка на Ru-Center (5 шагов)

1. Панель Ru-Center → **Хостинг** → ваш домен → «Файловый менеджер» (или подключитесь по FTP/SFTP:
   логин и пароль там же, в разделе «Хостинг → Доступ по FTP»).
2. Откройте каталог сайта: обычно `/www/<домен>/public_html` или `/public_html`.
3. Загрузите `rucenter-site.zip` и распакуйте его **в корень** `public_html` (чтобы `index.html` лежал рядом с папкой `api`, а не внутри ещё одной папки).
4. В панели: **PHP → версия 8.0 или выше**, расширение `openssl` включено (по умолчанию включено).
5. Откройте `https://ваш-домен/api/plans.php` — должен вернуться JSON с двумя тарифами. Если вернулся код PHP текстом, значит PHP не включён для каталога.

### Обязательно перед публикацией

- [ ] В `api/config.php` заменить `admin_secret` на свой пароль (или задать переменную окружения `MS_ADMIN_SECRET`).
- [ ] При желании перегенерировать ключ подписи: новая пара ECDSA P-256, приватный ключ → `api/keys/private.pem`, публичный → `MS_LICENSE.PUBLIC_KEY_B64` в `extension/license.js` (иначе старые ключи перестанут проверяться).
- [ ] В `index.html`, `buy.html`, `privacy.html`, `offer.html` заменить: `hello@example.ru`, телефон для СБП, ФИО, ИНН, название банка.
- [ ] В `extension/license.js` указать `MS_PRICING.purchaseUrl = 'https://ваш-домен/buy.html'` и пересобрать zip в `download/`.
- [ ] Проверить загрузку архива: `https://ваш-домен/download/market-sniper-0.3.0.zip`.

## Выдача ключа после оплаты

1. Открыть `https://ваш-домен/api/admin.php`, ввести пароль, выбрать тариф, вписать номер заказа или почту → получить ключ.
2. Отправить ключ покупателю письмом, пробить чек в «Мой налог».
3. Журнал выдачи: `api/data/issued.log`. Чтобы аннулировать ключ — добавить его `id` в `api/data/revoked.json` (массив строк), тогда `check.php` начнёт отвечать `valid: false`.

## Как проверить локально (без хостинга)

```powershell
cd D:\projects\market-sniper\site
$env:MS_ADMIN_SECRET='test-secret'; php -S 127.0.0.1:8111 -t .
# главная: http://127.0.0.1:8111/
# цены:    http://127.0.0.1:8111/api/plans.php
# выдача:  http://127.0.0.1:8111/api/admin.php  (пароль test-secret)
```

Автотест всего API (12 проверок, включая проверку ключа верификатором расширения):

```powershell
cd D:\projects\market-sniper\_scrape\test
node test-php-api.js
```
