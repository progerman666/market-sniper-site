<?php
declare(strict_types=1);

// Общие функции: конфиг, JSON-ответы, подпись ключей, лог выдачи.
function ms_config(): array
{
    static $config = null;
    if ($config === null) {
        $config = require __DIR__ . '/config.php';
    }
    return $config;
}

function ms_json_out($data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-Admin-Secret');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function ms_body(): array
{
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    if (is_array($data)) {
        return $data;
    }
    return $_POST ?: [];
}

function ms_b64url(string $bin): string
{
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

// PHP/OpenSSL отдаёт подпись ECDSA в DER, а браузер (WebCrypto) ждёт «сырые» r||s (64 байта).
function ms_der_to_raw(string $der): string
{
    if (strlen($der) < 8 || ord($der[0]) !== 0x30) {
        return $der;
    }

    $offset = 2;
    if ((ord($der[1]) & 0x80) !== 0) {
        $offset = 2 + (ord($der[1]) & 0x7f);
    }

    $out = '';
    for ($i = 0; $i < 2; $i++) {
        if (!isset($der[$offset]) || ord($der[$offset]) !== 0x02) {
            return $der;
        }
        $len = ord($der[$offset + 1]);
        $value = substr($der, $offset + 2, $len);
        $offset += 2 + $len;

        $value = ltrim($value, "\x00");
        $value = str_pad($value, 32, "\x00", STR_PAD_LEFT);
        $out .= $value;
    }

    return strlen($out) === 64 ? $out : $der;
}

function ms_raw_to_der(string $raw): string
{
    if (strlen($raw) !== 64) {
        return $raw;
    }

    $r = ltrim(substr($raw, 0, 32), "\x00");
    $s = ltrim(substr($raw, 32, 32), "\x00");
    $r = $r === '' ? "\x00" : $r;
    $s = $s === '' ? "\x00" : $s;
    if (ord($r[0]) & 0x80) {
        $r = "\x00" . $r;
    }
    if (ord($s[0]) & 0x80) {
        $s = "\x00" . $s;
    }

    $sequence = "\x02" . chr(strlen($r)) . $r . "\x02" . chr(strlen($s)) . $s;
    return "\x30" . chr(strlen($sequence)) . $sequence;
}

// Ключ = MS1.<base64url(payload)>.<base64url(подпись ECDSA P-256)>
function ms_sign(array $payload): string
{
    $cfg = ms_config();
    $pem = @file_get_contents($cfg['private_key_path']);
    if (!$pem) {
        ms_json_out(['error' => 'на сервере нет приватного ключа'], 500);
    }

    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!openssl_sign($json, $signature, $pem, OPENSSL_ALGO_SHA256)) {
        ms_json_out(['error' => 'не удалось подписать ключ'], 500);
    }

    return 'MS1.' . ms_b64url($json) . '.' . ms_b64url(ms_der_to_raw($signature));
}

function ms_key_id(string $token): string
{
    return substr(hash('sha256', $token), 0, 32);
}

function ms_data_dir(): string
{
    $cfg = ms_config();
    $dir = $cfg['data_dir'];
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    return $dir;
}

function ms_is_revoked(string $id): bool
{
    $file = ms_data_dir() . '/revoked.json';
    if (!is_file($file)) {
        return false;
    }
    $list = json_decode((string) @file_get_contents($file), true);
    return is_array($list) && in_array($id, $list, true);
}

// Единая точка выдачи ключа: plan ('month'|'year') или days.
function ms_issue(array $body): array
{
    $cfg = ms_config();
    $planName = isset($cfg['plans'][$body['plan'] ?? '']) ? $body['plan'] : 'month';
    $plan = $cfg['plans'][$planName];

    $days = isset($body['days']) ? (int) $body['days'] : (int) $plan['days'];
    $days = max(1, min(400, $days));

    $exp = time() + $days * 86400;
    $payload = [
        'v' => 1,
        'tier' => 'pro',
        'exp' => $exp,
        'sub' => (string) ($body['order'] ?? ''),
        'plan' => $planName,
    ];

    $token = ms_sign($payload);
    $id = ms_key_id($token);

    $record = [
        'id' => $id,
        'plan' => $planName,
        'days' => $days,
        'exp' => $exp,
        'order' => $payload['sub'],
        'created' => date('c'),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
    ];
    @file_put_contents(
        ms_data_dir() . '/issued.log',
        json_encode($record, JSON_UNESCAPED_UNICODE) . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );

    return [
        'key' => $token,
        'exp' => $exp,
        'tier' => 'pro',
        'id' => $id,
        'days' => $days,
        'plan' => $planName,
        'price' => (int) $plan['price'],
    ];
}
